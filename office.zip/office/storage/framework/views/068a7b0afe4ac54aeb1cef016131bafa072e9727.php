<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php if(\Illuminate\Support\Facades\Session::has('created')): ?>
            <li><?php echo e(\Illuminate\Contracts\Session\Session::get('created')); ?></li>
        <?php endif; ?>
    </ul>
</div>
<?php endif; ?>